const questions = [
    { question: "What is the capital of France?", options: ["London", "Paris", "Berlin", "Rome"], answer: 1 },
    { question: "What is the largest planet in our solar system?", options: ["Earth", "Jupiter", "Mars", "Venus"], answer: 1 },
    { question: "Which country has the highest polulation in the world?", options: ["China", "brazil", "USA", "India"], answer: 4 },
    { question: "Which country has world's greatest gdp growth?", options: ["USA", "China", "Germany", "India"], answer: 4 },
    { question: "How many states are ther in India?", options: ["29", "28", "34", "38"], answer: 2 },
    { question: "What is the capital of India?", options: ["Mumbai", "Delhi", "Banglore", "Nagpur"], answer: 2 },
    { question: "which is the largest country in the world area wise?", options: ["Russia", "China", "Canada", "USA"], answer: 1 },
    { question: "what is the quareroot of 2500?", options: ["5", "50", "500", "0.5"], answer: 2 },
    { question: "which is the world's smallest country?", options: ["haiti", "brunae", "vatican city", "monaco"], answer: 3 },
    
    // Add more questions here
  ];
  
  let currentQuestion = 0;
  let score = 0;
  
  function displayQuestion() {
    const questionElement = document.getElementById("question");
    questionElement.textContent = questions[currentQuestion].question;
  
    // Update answer choices dynamically
    const buttons = document.querySelectorAll(".buttons button");
    buttons.forEach((button, index) => {
      button.textContent = questions[currentQuestion].options[index];
      button.addEventListener("click", function() {
        checkAnswer(index);
      });
    });
  }
  
  function checkAnswer(selectedOption) {
    const correctAnswer = questions[currentQuestion].answer;
    if (selectedOption === correctAnswer) {
      score++;
    }
  
    currentQuestion++;
  
    if (currentQuestion === questions.length) {
      showResult();
    } else {
      displayQuestion();
    }
  }
  
  function showResult() {
    const scoreElement = document.getElementById("score");
    scoreElement.textContent = `Your score is ${score} out of ${questions.length}`;
  
    // Disable buttons or display a message after the quiz
    const buttons = document.querySelectorAll(".buttons button");
    buttons.forEach(button => button.disabled = true);
    // You can also display a message like "Quiz completed!" here
  }
  
  displayQuestion();
  